# Projet-ARE-abeilles

LE MESLE Maxime
ASSAAD Elsa
CHOUVIN Juliette
BOUFRAD Inès


Sujet: étudier l'évolution d'une population d'abeilles dans une région donnée, selon l'impact humain (pesticides et pollutions), prédation (frelon et co...), présence de fleurs...
